const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const dir = path.join(__dirname, 'data');
if (!fs.existsSync(dir)) fs.mkdirSync(dir);
const dbPath = path.join(dir, 'init.sqlite3');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL, image TEXT)`);
  db.run(`CREATE TABLE IF NOT EXISTS cart (id INTEGER PRIMARY KEY, productId INTEGER, qty INTEGER, FOREIGN KEY(productId) REFERENCES products(id))`);
  db.get("SELECT COUNT(*) as cnt FROM products", (err, row) => {
    if (!row.cnt) {
      const stmt = db.prepare("INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
      [["Vibe T-Shirt",499,""],["Vibe Jeans",1199,""],["Vibe Sneakers",2499,""],["Vibe Cap",299,""],["Vibe Hoodie",1599,""],["Vibe Mug",199,""]].forEach(p=>stmt.run(p));
      stmt.finalize();
    }
  });
});
module.exports = db;
