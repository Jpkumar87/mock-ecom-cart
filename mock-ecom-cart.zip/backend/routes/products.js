const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req,res)=>{
  db.all("SELECT id,name,price,image FROM products",(e,r)=>{
    if(e) return res.status(500).json({error:e.message});
    res.json(r);
  });
});
module.exports = router;
