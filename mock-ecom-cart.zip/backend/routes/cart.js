const express=require('express');
const router=express.Router();
const db=require('../db');

router.get('/',(req,res)=>{
  const sql=`SELECT c.id as cartId,p.id as productId,p.name,p.price,p.image,c.qty
             FROM cart c JOIN products p ON c.productId=p.id`;
  db.all(sql,(e,r)=>{
    if(e) return res.status(500).json({error:e.message});
    const total=r.reduce((s,i)=>s+i.price*i.qty,0);
    res.json({items:r,total});
  });
});

router.post('/',(req,res)=>{
  const {productId,qty}=req.body;
  if(!productId||!qty) return res.status(400).json({error:"productId and qty required"});
  db.get("SELECT id,qty FROM cart WHERE productId=?",[productId],(e,row)=>{
    if(row){
      db.run("UPDATE cart SET qty=? WHERE id=?",[row.qty+qty,row.id],err=>{
        if(err) return res.status(500).json({error:err.message});
        res.json({ok:true});
      });
    }else{
      db.run("INSERT INTO cart (productId,qty) VALUES (?,?)",[productId,qty],function(err){
        if(err) return res.status(500).json({error:err.message});
        res.json({ok:true,id:this.lastID});
      });
    }
  });
});

router.put('/:id',(req,res)=>{
  db.run("UPDATE cart SET qty=? WHERE id=?",[req.body.qty,req.params.id],err=>{
    if(err) return res.status(500).json({error:err.message});
    res.json({ok:true});
  });
});

router.delete('/:id',(req,res)=>{
  db.run("DELETE FROM cart WHERE id=?",[req.params.id],err=>{
    if(err) return res.status(500).json({error:err.message});
    res.json({ok:true});
  });
});

router.post('/checkout',(req,res)=>{
  const {name,email}=req.body;
  const sql=`SELECT p.id as productId,p.name,p.price,c.qty
             FROM cart c JOIN products p ON c.productId=p.id`;
  db.all(sql,(e,r)=>{
    const total=r.reduce((s,i)=>s+i.price*i.qty,0);
    const receipt={id:Date.now(),name,email,items:r,total,timestamp:new Date().toISOString()};
    db.run("DELETE FROM cart",[],()=>res.json({receipt}));
  });
});
module.exports=router;
